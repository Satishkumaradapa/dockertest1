/*!
 =========================================================
 * Apex Angular 4 Bootstrap theme - V1.0
 =========================================================

 * Product Page: https://www.pixinvent.com/product/apex
 * Copyright 2017 Pixinvent Creative Studio (https://www.pixinvent.com)

 =========================================================
*/
$(document).ready(function() {

    function checkbox(e) {
    console.log(e);
  var checked = $(this).prop("checked"),
      container = $(this).parent(),
      siblings = container.siblings();

  container.find('input[type="checkbox"]').prop({
    indeterminate: false,
    checked: checked
  });

  function checkSiblings(el) {

    var parent = el.parent().parent(),
        all = true;

    el.siblings().each(function() {
      return all = ($(this).children('input[type="checkbox"]').prop("checked") === checked);
    });

    if (all && checked) {

      parent.children('input[type="checkbox"]').prop({
        indeterminate: false,
        checked: checked
      });

      checkSiblings(parent);

    } else if (all && !checked) {

      parent.children('input[type="checkbox"]').prop("checked", checked);
      parent.children('input[type="checkbox"]').prop("indeterminate", (parent.find('input[type="checkbox"]:checked').length > 0));
      checkSiblings(parent);

    } else {

      el.parents("li").children('input[type="checkbox"]').prop({
        indeterminate: true,
        checked: false
      });

    }

  }

  checkSiblings(container);
};
    // $(".addnewevent").click(function() {
    //     console.log('addnewevent');
    // $('html,body').animate({
    //     scrollTop: $(".calendar_list").offset().top},
    //     'slow');
    // });

    $('.expand_accountant').toggle("slide");

    $('body').on('click', '.showmenu', function() {
        $(".report_expand").hide();
        var expand = $(this).data("expand-id");
        $('.' + expand + '').toggle("slide");
    });


    var $sidebar = $('.app-sidebar'),
        $sidebar_content = $('.sidebar-content'),
        $sidebar_img = $sidebar.data('image'),
        $sidebar_img_container = $('.sidebar-background'),
        $wrapper = $('.wrapper');

    // $sidebar_content.perfectScrollbar();

    if ($sidebar_img_container.length !== 0 && $sidebar_img !== undefined) {
        $sidebar_img_container.css('background-image', 'url("' + $sidebar_img + '")');
    }

    if (!$wrapper.hasClass('nav-collapsed')) {
        listItem = $('.navigation li.parentclass');
        if (listItem.hasClass('has-sub')) {
            expand(listItem);
        }
        //$sidebar_content.find('li.active').parents('li').addClass('open');
    }

    $('body').on('click', '.filter-sidebar-content .navigation li.has-sub a', function() {
        // $sidebar_content.on('click', '.navigation li a', function() {
        // console.log("sidebard");
        var $this = $(this),
            listItem = $this.parent('li');

        if (listItem.hasClass('has-sub') && listItem.hasClass('open')) {
            collapse(listItem);
        } else {
            if (listItem.hasClass('has-sub')) {
                expand(listItem);
            }

            // If menu collapsible then do not take any action
            if ($sidebar_content.data('collapsible')) {
                return false;
            }
            // If menu accordion then close all except clicked once
            else {
                // openListItems = listItem.siblings('.open');
                // collapse(openListItems);
                // listItem.siblings('.open').find('li.open').removeClass('open');
            }
        }
    });

    $('.logo-text').on('click', function() {

        var listItem = $sidebar_content.find('li.open.has-sub'),
            activeItem = $sidebar_content.find('li.active');

        if (listItem.hasClass('has-sub') && listItem.hasClass('open')) {
            // collapse(listItem);
            listItem.removeClass('open');
            if (activeItem.closest('li.has-sub')) {
                openItem = activeItem.closest('li.has-sub');
                expand(openItem);
                openItem.addClass('open');
            }
        } else {
            if (activeItem.closest('li.has-sub')) {
                openItem = activeItem.closest('li.has-sub');
                expand(openItem);
                openItem.addClass('open');
            }
        }
    });

    $sidebar.on('mouseenter', function() {
        /*if($wrapper.hasClass('nav-collapsed')){
            $wrapper.removeClass('menu-collapsed');
            var $listItem = $('.navigation li.nav-collapsed-open'),
            $subList = $listItem.children('ul');

            $subList.hide().slideDown(300, function() {
                $(this).css('display', '');
            });

            $sidebar_content.find('li.active').parents('li').addClass('open');
            $listItem.addClass('open').removeClass('nav-collapsed-open');
        }*/
    }).on('mouseleave', function(event) {
        if ($wrapper.hasClass('nav-collapsed')) {
            $wrapper.addClass('menu-collapsed');
            var $listItem = $('.navigation li.open'),
                $subList = $listItem.children('ul');
            $listItem.addClass('nav-collapsed-open');

            $subList.show().slideUp(300, function() {
                $(this).css('display', '');
            });

            $listItem.removeClass('open');
        }
    });

    if ($(window).width() < 992) {
        $sidebar.addClass('hide-sidebar');
        $wrapper.removeClass('nav-collapsed menu-collapsed');
    }
    $(window).resize(function() {
        if ($(window).width() < 992) {
            $sidebar.addClass('hide-sidebar');
            $wrapper.removeClass('nav-collapsed menu-collapsed');
        }
        if ($(window).width() > 992) {
            $sidebar.removeClass('hide-sidebar');
            if ($('.toggle-icon').attr('data-toggle') === 'collapsed' && $wrapper.not('.nav-collapsed menu-collapsed')) {
                $wrapper.addClass('nav-collapsed menu-collapsed');
            }
        }
    });

    $(document).on('click', '.navigation li:not(.has-sub)', function() {
        if ($(window).width() < 992) {
            $sidebar.addClass('hide-sidebar');
        }
    });

    $(document).on('click', '.logo-text', function() {
        if ($(window).width() < 992) {
            $sidebar.addClass('hide-sidebar');
        }
    });


    $('.navbar-toggle').on('click', function(e) {
        e.stopPropagation();
        $sidebar.toggleClass('hide-sidebar');
    });

    $('html').on('click', function(e) {
        if ($(window).width() < 992) {
            if (!$sidebar.hasClass('hide-sidebar') && $sidebar.has(e.target).length === 0) {
                $sidebar.addClass('hide-sidebar');
            }
        }
    });

    $('#sidebarClose').on('click', function() {
        $sidebar.addClass('hide-sidebar');
    });

    // $('.noti-list').perfectScrollbar();
    // $('.dashboard_scroll').perfectScrollbar();

    $('button').click(function(e) {
        $('#myDiv').toggleClass('fullscreen');
    });

});
function collapse($listItem, callback) {
    var $subList = $listItem.children('ul');

    $subList.show().slideUp(200, function() {
        $(this).css('display', '');

        $(this).find('> li').removeClass('is-shown');

        $listItem.removeClass('open');

        if (callback) {
            callback();
        }
    });

}

function expand($listItem, callback) {
    var $subList = $listItem.children('ul');
    var $children = $subList.children('li').addClass('is-hidden');

    $listItem.addClass('open');

    $subList.hide().slideDown(200, function() {
        $(this).css('display', '');

        if (callback) {
            callback();
        }
    });



    setTimeout(function() {
        $children.addClass('is-shown');
        $children.removeClass('is-hidden');
    }, 0);
}
    
function navToggle(url,flag) {
    $wrapper = $('.wrapper');
    // console.log(url);
    var toggle_icon = $('.nav-toggle').find('.toggle-icon'),
        toggle = toggle_icon.attr('data-toggle'),
        compact_menu_checkbox = $('.cz-compact-menu');
    // console.log(toggle);
    if(url != '/analytics/expense' && url != '/analytics/income' && toggle == 'collapsed'){
        $wrapper.removeClass('nav-collapsed menu-collapsed');

        $('.nav-toggle').find('.toggle-icon').removeClass('ft-chevrons-right').addClass('ft-chevrons-left');
        toggle_icon.attr('data-toggle', 'expanded');
        // console.log('data-toggle');
        if (compact_menu_checkbox.length > 0) {
            compact_menu_checkbox.prop('checked', false);
        }
    }else if(flag){
        if (toggle === 'expanded') {
            var listItem = $('.navigation li.parentclass');
            collapse(listItem);
            $wrapper.addClass('nav-collapsed');

            $('.nav-toggle').find('.toggle-icon').removeClass('ft-chevrons-left').addClass('ft-chevrons-right');
            toggle_icon.attr('data-toggle', 'collapsed');
            if (compact_menu_checkbox.length > 0) {
                compact_menu_checkbox.prop('checked', true);
            }
        } else {
            $wrapper.removeClass('nav-collapsed menu-collapsed');

            $('.nav-toggle').find('.toggle-icon').removeClass('ft-chevrons-right').addClass('ft-chevrons-left');
            toggle_icon.attr('data-toggle', 'expanded');
            // console.log('data-toggle');
            if (compact_menu_checkbox.length > 0) {
                compact_menu_checkbox.prop('checked', false);
            }
        }
    }
};