//import { link } from "fs";

// const hamburger = document.querySelector('.hamburger');
// const navLinks = document.querySelector('.nav-links');
// const links = document.querySelectorAll('.nav-link li');

// $(document).ready( function(){ 

// hamburger.addEventListener("click", () => {
//     navLinks.classList.toggle("open");
//     links.forEach(link => {
//         links.classList.toggle("fade");
//     });
// });
// });